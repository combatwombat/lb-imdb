if (typeof browser === 'undefined') {
    var browser = chrome;
}

// Fallback hash - used if fetching from GitHub fails
const FALLBACK_QUERY_HASH = '1986bb7212d96dd5826ea3533fbada409029b2158ae4d878e9cfb5818f0b3b33';

// URL to fetch current hash from GitHub Pages
const HASH_URL = 'https://combatwombat.github.io/lb-imdb/hash.txt';

// Storage key for cached hash
const STORAGE_KEY = 'queryHash';

const GRAPHQL_ENDPOINT = 'https://caching.graphql.imdb.com/';
const IMDB_REFERER = 'https://www.imdb.com/';

// IMDb now gates the GraphQL endpoint on two headers we can't set from plain JS:
// without an imdb.com Referer it answers 403, and without a real
// "Content-Type: application/json" it answers 415. Referer is a forbidden header
// for fetch(), and browsers drop Content-Type from a body-less GET - so we POST
// (which gives us a genuine Content-Type) and set the Referer at the network layer.
// Chrome (MV3) does that with the declarative_net_request ruleset in rules.json;
// Firefox (MV2) needs the blocking webRequest listener below.
if (typeof browser !== 'undefined' && browser.webRequest?.onBeforeSendHeaders) {
    browser.webRequest.onBeforeSendHeaders.addListener(
        details => {
            const headers = details.requestHeaders.filter(h => h.name.toLowerCase() !== 'referer');
            headers.push({ name: 'Referer', value: IMDB_REFERER });
            return { requestHeaders: headers };
        },
        { urls: [GRAPHQL_ENDPOINT + '*'] },
        ['blocking', 'requestHeaders']
    );
}

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[lb-imdb bg] received message:', message);

    // Request from content.js to fetch trivia
    if (message.action === "fetchTrivia") {
        console.log('[lb-imdb bg] fetchTrivia request for', message.imdbCode);
        fetchTriviaViaGraphQL(message.imdbCode)
            .then(data => sendResponse({ success: true, data: data }))
            .catch(err => {
                console.error('[lb-imdb bg] fetchTrivia failed:', err);
                sendResponse({ success: false, error: err.message });
            });
        return true; // Keep channel open for async response
    }

    // Open options page
    if (message.action === "openOptionsPage") {
        browser.runtime.openOptionsPage();
    }
});

/**
 * Get the query hash with caching:
 * 1. Check browser.storage.local for cached hash
 * 2. If not cached, fetch from GitHub Pages
 * 3. Store fetched hash in browser.storage.local
 * 4. If fetch fails, return FALLBACK_QUERY_HASH
 *
 * @param {boolean} forceRefresh - If true, skip cache and fetch fresh hash
 */
async function getQueryHash(forceRefresh = false) {
    // Check cache first (unless forcing refresh)
    if (!forceRefresh) {
        try {
            const stored = await browser.storage.local.get(STORAGE_KEY);
            if (stored[STORAGE_KEY]) {
                console.log('[lb-imdb bg] using cached hash:', stored[STORAGE_KEY]);
                return stored[STORAGE_KEY];
            }
        } catch (e) {
            console.log('[lb-imdb bg] could not read from storage:', e);
        }
    }

    // Fetch from GitHub Pages
    try {
        console.log('[lb-imdb bg] fetching hash from:', HASH_URL);
        // GitHub Pages serves hash.txt with max-age=600. After a rotation we must
        // not be handed the stale copy from the HTTP cache, so bypass it.
        const response = await fetch(HASH_URL, { cache: 'no-store' });
        if (response.ok) {
            const hash = (await response.text()).trim();
            if (hash && hash.length === 64) { // SHA-256 is 64 hex chars
                console.log('[lb-imdb bg] fetched hash:', hash);
                // Cache it
                await browser.storage.local.set({ [STORAGE_KEY]: hash });
                return hash;
            }
        }
    } catch (e) {
        console.log('[lb-imdb bg] could not fetch hash:', e);
    }

    // Fall back to hardcoded hash
    console.log('[lb-imdb bg] using fallback hash');
    return FALLBACK_QUERY_HASH;
}

/**
 * Clear cached hash (call when hash is invalid)
 */
async function clearCachedHash() {
    try {
        await browser.storage.local.remove(STORAGE_KEY);
        console.log('[lb-imdb bg] cleared cached hash');
    } catch (e) {
        console.log('[lb-imdb bg] could not clear cache:', e);
    }
}

/**
 * Main function: Fetch trivia via GraphQL API
 */
async function fetchTriviaViaGraphQL(imdbCode) {
    console.log('[lb-imdb bg] fetching trivia via GraphQL for', imdbCode);

    let queryHash = await getQueryHash();

    try {
        return await fetchTriviaWithHash(imdbCode, queryHash);
    } catch (err) {
        // If hash failed, try fetching a fresh hash from GitHub
        if (err.message.includes('PersistedQueryNotFound')) {
            console.log('[lb-imdb bg] hash invalid, fetching fresh hash...');
            await clearCachedHash();
            const failedHash = queryHash;
            queryHash = await getQueryHash(true); // Force refresh

            // If we got the same hash back, GitHub has nothing newer yet - give up
            if (queryHash === failedHash) {
                throw new Error('Could not fetch trivia: hash is outdated');
            }

            return await fetchTriviaWithHash(imdbCode, queryHash);
        }
        throw err;
    }
}

/**
 * Fetch trivia using a specific hash
 */
async function fetchTriviaWithHash(imdbCode, queryHash) {
    console.log('[lb-imdb bg] using query hash:', queryHash);

    // Fetch trivia data (spoilers and non-spoilers)
    const [nonSpoilerItems, spoilerItems] = await Promise.all([
        fetchAllTriviaPages(imdbCode, queryHash, false),
        fetchAllTriviaPages(imdbCode, queryHash, true)
    ]);

    console.log('[lb-imdb bg] fetched', nonSpoilerItems.length, 'non-spoiler items and', spoilerItems.length, 'spoiler items');

    // Process into categories
    const categories = processTriviaCategories(nonSpoilerItems, spoilerItems);
    const numItems = nonSpoilerItems.length + spoilerItems.length;

    return { categories, numItems };
}

/**
 * Fetch all trivia pages (handles pagination)
 */
async function fetchAllTriviaPages(imdbCode, queryHash, spoilers, pagePointer = null) {
    let triviaItems = [];

    const variables = {
        "const": imdbCode,
        "filter": {
            "spoilers": spoilers ? "SPOILERS_ONLY" : "EXCLUDE_SPOILERS"
        },
        "first": 50,
        "locale": "en-US",
        "originalTitleText": false
    };

    if (pagePointer) {
        variables.after = pagePointer;
    }

    const extensions = {
        "persistedQuery": {
            "sha256Hash": queryHash,
            "version": 1
        }
    };

    const response = await fetch(GRAPHQL_ENDPOINT, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/graphql+json, application/json'
        },
        body: JSON.stringify({
            operationName: 'TitleTriviaPagination',
            variables: variables,
            extensions: extensions
        })
    });

    if (!response.ok) {
        throw new Error(`GraphQL request failed: ${response.status}`);
    }

    const data = await response.json();

    if (data.errors) {
        if (data.errors.some(e => e.message?.includes('PersistedQueryNotFound'))) {
            throw new Error('PersistedQueryNotFound - hash may have changed');
        }
        throw new Error('GraphQL errors: ' + JSON.stringify(data.errors));
    }

    if (data.data?.title?.trivia?.edges) {
        triviaItems.push(...data.data.title.trivia.edges);

        // Handle pagination
        if (data.data.title.trivia.pageInfo?.hasNextPage) {
            const nextPage = await fetchAllTriviaPages(
                imdbCode,
                queryHash,
                spoilers,
                data.data.title.trivia.pageInfo.endCursor
            );
            triviaItems.push(...nextPage);
        }
    }

    return triviaItems;
}

/**
 * Process trivia items into categories
 */
function processTriviaCategories(nonSpoilerItems, spoilerItems) {
    const categories = {};

    function processItems(items, itemType) {
        items.forEach(item => {
            const node = item.node;
            const categoryText = node.category?.text || 'Uncategorized';
            const categoryId = node.category?.id || 'uncategorized';
            const html = node.displayableArticle?.body?.plaidHtml || '';

            if (!categories[categoryId]) {
                categories[categoryId] = {
                    category: categoryText,
                    nonSpoilerItems: [],
                    spoilerItems: []
                };
            }

            categories[categoryId][itemType].push(html);
        });
    }

    processItems(nonSpoilerItems, 'nonSpoilerItems');
    processItems(spoilerItems, 'spoilerItems');

    return categories;
}
