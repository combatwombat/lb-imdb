(function() {
    Bxd().tabbedContent();
})();